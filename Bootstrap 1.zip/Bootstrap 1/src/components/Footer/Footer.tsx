const Footer = () => {
    return(
        <>
        Footer
        
        </>    
    )

}

export default Footer
