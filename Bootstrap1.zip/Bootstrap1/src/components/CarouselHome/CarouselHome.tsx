import Carousel from 'react-bootstrap/Carousel';

const CarouselHome = () => {
return(
    <Carousel>
    <Carousel.Item>

      <img 
      className='d-block w-100'
      style={{maxHeight:"450px "}}
      src="src/assets/agil.jpeg" alt="slide1" />
      <Carousel.Caption>
        <h3>Aplicamos metodologias ágiles</h3>
        <p>Para que su producto esté en tiempo y forma</p>
      </Carousel.Caption>
    </Carousel.Item>


    <Carousel.Item>
    <img 
      className='d-block w-100'
      style={{maxHeight:"450px "}}
      src="src/assets/impulso.jpg" alt="slide2" />
      <Carousel.Caption>
        <h3>Directo a la estratósfera</h3>
        <p>Impulsamos su proyecto</p>
      </Carousel.Caption>
    </Carousel.Item>



    <Carousel.Item>
    <img 
      className='d-block w-100'
      style={{maxHeight:"450px "}}
      src="src/assets/oficinas.jpg" alt="slide3" />
      <Carousel.Caption>
        <h3>Visitenos</h3>
        <p>
          Nuestras oficinas están equipadas con lo último en software y hardware
        </p>
      </Carousel.Caption>
    </Carousel.Item>
  </Carousel>
)
}
export default CarouselHome