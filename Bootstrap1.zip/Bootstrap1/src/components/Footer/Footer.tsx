const Footer = () => {
    return(
        <><div className="main-footer widgets-dark typo-light">
            <div className="container">
                <div className="row">

                    <div className="col-xs-12 col-sm-6 col-md-3">
                        <div className="widget subscribe no-box">
                            <h5 className="widget-title">AgilProgram<span></span></h5>
                            <p>Software Factory</p>
                        </div>
                    </div>

                   

                    

                    <div className="col-xs-12 col-sm-6 col-md-3">

                        <div className="widget no-box">
                            <h5 className="widget-title">Contáctanos<span></span></h5>

                            <p><a  title="email">aguerodamian15@gmail.com</a></p>
                            <p><a  title="telefono">+ 54 261 3732618</a></p>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div><div className="footer-copyright">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            <p>AgilProgram© 2023. Todos los derechos reservados.</p>
                        </div>
                    </div>
                </div>
            </div></>   
    )

}

export default Footer
