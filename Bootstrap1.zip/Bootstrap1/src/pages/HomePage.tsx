
import CarouselHome from "../components/CarouselHome/CarouselHome"

const HomePage = () => {
    return(
        <>
        <CarouselHome/>
        
        </>    
    )

}

export default HomePage