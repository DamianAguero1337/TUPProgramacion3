import { Routes, Route } from "react-router-dom"
import HomePage from "../pages/HomePage"
import Tareas from "../pages/Tareas"

const AppRoutes:React.FC = () => {
    return(
        <Routes>
            <Route path= "/" element={<HomePage/>}/>
            <Route path= "/tareas" element={<Tareas/>}/>
        </Routes>    
    )

}

export default AppRoutes