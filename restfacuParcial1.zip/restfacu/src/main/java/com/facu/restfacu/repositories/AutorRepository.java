package com.facu.restfacu.repositories;

import com.facu.restfacu.entities.Persona;
import org.springframework.stereotype.Repository;

@Repository
public interface AutorRepository extends BaseRepository<Persona, Long> {

}
