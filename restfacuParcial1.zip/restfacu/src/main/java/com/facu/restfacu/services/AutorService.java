package com.facu.restfacu.services;

import com.facu.restfacu.entities.Autor;

public interface AutorService extends BaseService<Autor, Long>{

}
