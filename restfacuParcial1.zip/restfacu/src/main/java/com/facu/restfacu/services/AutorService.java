package com.facu.restfacu.services;

public interface AutorService extends BaseService<Autor, Long>{

}
