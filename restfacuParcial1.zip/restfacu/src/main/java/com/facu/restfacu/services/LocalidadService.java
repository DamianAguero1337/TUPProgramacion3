package com.facu.restfacu.services;

import com.facu.restfacu.entities.Localidad;

public interface LocalidadService extends BaseService<Localidad,Long>{

}
