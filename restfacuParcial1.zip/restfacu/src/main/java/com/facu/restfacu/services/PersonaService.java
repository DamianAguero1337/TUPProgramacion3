package com.facu.restfacu.services;

import com.facu.restfacu.entities.Persona;

public interface PersonaService extends BaseService<Persona, Long>{

}
