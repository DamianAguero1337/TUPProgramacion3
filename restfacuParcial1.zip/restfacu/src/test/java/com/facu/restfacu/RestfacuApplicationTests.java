package com.facu.restfacu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfacuApplicationTests {

	@Test
	void contextLoads() {
	}

}
